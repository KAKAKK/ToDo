﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ToDo
{
    public partial class SetAlarm : Form
    {
        //设置获取的id的变量
        int getId;

        public SetAlarm(int planId)
        {
            //将myPlan表的id 传给 getId
            getId  = planId;

            InitializeComponent();
        }

        private void SetAlarm_Load(object sender, EventArgs e)
        {
            //将id显示到文本框中
            myId.Text = getId.ToString();

        }
    }
}
